
package com.mycompany.mattresssalescompany;

/**
 *
 * @author Student
 */
public interface IProduct {
    int GetTotalProductsSold();
    double GetAverageProductSold();
    String GetMostPopularPoduct();
    int GetTotalSales();
    String GetMattressType();
    String Months();
}
