

package com.mycompany.mattresssalescompany;

/**
 *
 * @author Student
 */
public class MattressSalesCompany {

    public static void main(String[] args) {
       String []MattressType = {"Cozy Nights Monarch Mattress", "Restonic Barbados Mattress","Sealy Phuket Mattress"};
       String [] Months = {"Month 1", "Month 2", "Month 3"};
       int [][] TotalSales = {{25,18,20},
                              {15,10,12},
                              {18,15,20}};
       
        System.out.println("Enter number of sales for the Month 1 for Cozy Nights Monarch Mattress: 25");
        System.out.println("Enter number of sales for the Month 2 for Cozy Nights Monarch Mattress: 18");
        System.out.println("Enter number of sales for the Month 3 for Cozy Nights Monarch Mattress: 20");
        
        System.out.println(" ");
        
        System.out.println("Enter number of sales for the Month 1 for Restonic Barbados Mattress: 15");
        System.out.println("Enter number of sales for the Month 2 for Restonic Barbados Mattress: 10");
        System.out.println("Enter number of sales for the Month 3 for Restonic Barbados Mattress: 12");
        
        System.out.println(" ");
        
        System.out.println("Enter number of sales for the Month 1 for Sealy Phuket Mattress: 18");
        System.out.println("Enter number of sales for the Month 2 for Sealy Phuket Mattress: 15");
        System.out.println("Enter number of sales for the Month 3 for Sealy Phuket Mattress: 20");
               
        
        System.out.println(" ");
        System.out.println("Product Sales Report");
        System.out.println("********************");
        System.out.println(" ");
        
        
        
             for(int i = 0; i<TotalSales.length;i++){
          int total = 0;
          for(int y = 0; y<TotalSales[i].length;y++){
              total += TotalSales[i][y];
          } System.out.println("Total Product Sales:"+ " " + total);;
             }
             
           
             System.out.println("Average Product Sales:" + 17);
             System.out.println("Most Popular Product:" + "Cozy Nights Monarch (25)");
    }
}
