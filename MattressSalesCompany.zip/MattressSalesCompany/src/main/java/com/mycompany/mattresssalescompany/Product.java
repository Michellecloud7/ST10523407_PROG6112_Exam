
package com.mycompany.mattresssalescompany;

/**
 *
 * @author Student
 */
public abstract class Product implements IProduct {
    private int TotalProductsSold;
    private Double AverageProductSold;
    private String MostPopularProductSold;
    private String MattressType;
    private String Months;
    private int TotalSales;
    
    public Product(int TotalProductsSold, double AverageProductSold, String MostPopularProductSold, String MattressType, String Months, int TotalSales){ 
        this.TotalProductsSold = TotalProductsSold;
        this.AverageProductSold = AverageProductSold;
        this.MostPopularProductSold = MostPopularProductSold;
        this.MattressType = MattressType;
        this.Months = Months;
        this.TotalSales = TotalSales;
       
    }
    
    //Totals 
      
    
}
